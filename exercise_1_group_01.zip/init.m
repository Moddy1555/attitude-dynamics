%% GROUP_01 DETAILS
%  Authors:
%  - Modena Andrea 2157605
%  - Comunello Marco 2193512
%  - De Guio Riccardo 2157243
%  - Borghesan Alice 2196728

%% Integration steps
dt = 0.01;
tol = 1e-5;

%% Initial conditions 
% Cubesat 3U x=0.1 m; y=0.1 m; z=0.3 m; m=0.7+0.7+0.7=2.25 kg
x = 0.1;
y = 0.1;
z = 0.3;
m = 2.25;

% Calculation of moments of inertia Ix, Iy, Iz
Iz = m/12 * (x^2+y^2);   % kg*m^2
Ix = m/12 * (z^2+y^2);   % kg*m^2
Iy = Ix;                 % kg*m^2

% inertia matrix
I=[Ix  0  0;
    0 Iy  0;
    0  0 Iz]; 

% Orbital radius r0=700 km and calculation of orbital period
% T=2pi*sqrt(r^3/mu) s
re = 6371;   % km
r0 = re+700; % km
mu = 398600; % km^3/s^2

% Orbital period
T0 = 2*pi*sqrt(r0^3/mu); % s

% Sinusoidal torques Tx=5e-8 * cos(t), Ty=2e-8 * sin(t), Tz=3e-8 * sin(2t)
Ax = 5e-8;
omegax = 1e-2;
phasex = pi/2;

Ay = 2e-8;
omegay = 1e-2;
phasey = pi/2;

Az = 3e-8;
omegaz = 1e-2;
phasez = pi/2;

% Nadir pointing quaternion
q_IC=[0;0;0;1];

% Orbital velocity initial
omega_OI = 2*pi/T0;
omegaBI_IC = [0;-omega_OI;0];

